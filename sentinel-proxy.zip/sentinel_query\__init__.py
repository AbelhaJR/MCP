﻿import json
import os
import re
import requests
import azure.functions as func
from azure.identity import ClientSecretCredential

LOG_ANALYTICS_SCOPE = "https://api.loganalytics.io/.default"
LOG_ANALYTICS_URL = "https://api.loganalytics.io/v1/workspaces/{workspace_id}/query"

MAX_QUERY_CHARS = 8000
DEFAULT_TIMEOUT_S = 60
DEFAULT_TAKE = 100

FORBIDDEN_KQL = [
    r"\bexternaldata\b",
    r"\bevaluate\b",
    r"\binvoke\b",
    r"\bpython\b",
]

def _bad_kql(kql: str) -> str | None:
    k = kql.lower()
    for pat in FORBIDDEN_KQL:
        if re.search(pat, k):
            return f"Forbidden KQL pattern: {pat}"
    if len(kql) > MAX_QUERY_CHARS:
        return "KQL too large"
    return None

def _ensure_time_filter(kql: str) -> bool:
    kl = kql.lower()
    return ("timegenerated" in kl) and ("ago(" in kl)

def _ensure_row_limit_or_summarize(kql: str) -> str:
    kl = kql.lower()
    if ("| take " in kl) or ("| summarize" in kl):
        return kql
    return f"{kql}\n| take {DEFAULT_TAKE}"

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except Exception:
        return func.HttpResponse("Invalid JSON", status_code=400)

    workspace_id = body.get("workspace_id") or os.environ.get("WORKSPACE_ID")
    kql = body.get("kql")
    timeout_s = int(body.get("timeout_s", DEFAULT_TIMEOUT_S))

    if not workspace_id:
        return func.HttpResponse(json.dumps({"error": "workspace_id missing"}), status_code=400, mimetype="application/json")
    if not kql or not isinstance(kql, str):
        return func.HttpResponse(json.dumps({"error": "kql missing"}), status_code=400, mimetype="application/json")

    bad = _bad_kql(kql)
    if bad:
        return func.HttpResponse(json.dumps({"error": bad}), status_code=400, mimetype="application/json")

    if not _ensure_time_filter(kql):
        return func.HttpResponse(
            json.dumps({"error": "KQL must include a TimeGenerated filter with ago(...)."}),
            status_code=400,
            mimetype="application/json"
        )

    kql = _ensure_row_limit_or_summarize(kql)

    tenant_id = os.environ.get("TENANT_ID")
    client_id = os.environ.get("CLIENT_ID")
    client_secret = os.environ.get("CLIENT_SECRET")

    if not tenant_id or not client_id or not client_secret:
        return func.HttpResponse(
            json.dumps({"error": "Missing TENANT_ID / CLIENT_ID / CLIENT_SECRET app settings"}),
            status_code=500,
            mimetype="application/json"
        )

    cred = ClientSecretCredential(tenant_id=tenant_id, client_id=client_id, client_secret=client_secret)
    token = cred.get_token(LOG_ANALYTICS_SCOPE).token

    url = LOG_ANALYTICS_URL.format(workspace_id=workspace_id)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {"query": kql}

    try:
        r = requests.post(url, headers=headers, json=payload, timeout=timeout_s)
    except requests.Timeout:
        return func.HttpResponse(
            json.dumps({"error": "Query timed out", "suggestion": "Narrow the time range or summarize first."}),
            status_code=504,
            mimetype="application/json"
        )

    if r.status_code >= 400:
        return func.HttpResponse(
            json.dumps({"error": "Log Analytics API error", "status": r.status_code, "body": r.text[:1200]}),
            status_code=502,
            mimetype="application/json"
        )

    return func.HttpResponse(r.text, status_code=200, mimetype="application/json")
